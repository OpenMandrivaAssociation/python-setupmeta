"""
This __init__.py is not examined by setupmeta
"""

__keywords__ = "foo, bar"
