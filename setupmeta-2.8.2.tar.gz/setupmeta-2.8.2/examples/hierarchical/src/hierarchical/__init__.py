"""
A hierarchical package (code under src/, tests under tests/)

keywords: hierarchical, package
author: Someone someone@example.com
"""

__version__ = "1.0.0"
__url__ = "https://github.com/zsimic"
__download_url__ = "archive/{version}.tar.gz"


def main():
    pass
