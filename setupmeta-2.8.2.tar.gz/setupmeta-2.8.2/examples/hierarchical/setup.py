from setuptools import setup


setup(
    name="hierarchical",
    setup_requires=["setupmeta"],
)
