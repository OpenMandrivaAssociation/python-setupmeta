# via-cfg - All settings come from `setup.cfg`

Example where settings come from `setup.cfg`, instead of `setup.py`
