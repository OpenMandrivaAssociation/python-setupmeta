This mimics another module found at top of the repo, but shouldn't be picked up by setupmeta for `packages` auto-fill.
