"""
A package implemented by one direct (not under src/) module folder

keywords: direct, package
author: Someone someone@example.com
"""

__version__ = "1.0.0"
__url__ = "https://github.com/zsimic/simple"
__download_url__ = "https://github.com/zsimic/simple/archive/{version}.tar.gz"


def main():
    pass
