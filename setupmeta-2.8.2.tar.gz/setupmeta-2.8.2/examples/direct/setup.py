from setuptools import setup


setup(
    name="direct",
    setup_requires=["setupmeta"],
)
