# coding=utf-8
"""
Unicode chars in setup.py 😀 😎
"""

from setuptools import setup


setup(
    name="single",
    setup_requires=["setupmeta", "setuptools_scm"],
)
