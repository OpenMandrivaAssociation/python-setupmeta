"""
This is a python package implemented by a single .py file

license: MIT
author: Someone someone@example.com
"""

__version__ = "0.1.0"
