# bogus versioning spec

This scenario tests a bogus `versioning` specification in `setup.py`
