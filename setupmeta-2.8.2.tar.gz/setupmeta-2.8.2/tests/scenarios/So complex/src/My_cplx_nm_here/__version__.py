""" """

__version__ = "1.2.3"  # Ignored due to setuptools_scm ref
__maintainer__ = "Someone me@example.com"

__keywords__ = "complex, version"
