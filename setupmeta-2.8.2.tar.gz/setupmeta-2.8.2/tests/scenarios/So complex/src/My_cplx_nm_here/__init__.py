"""
Short description of complex project

Stuff can come from __init__.py too
"""

__keywords__ = "src, complex, init"
__version__ = '1.3.0'

# New style
__maintainer__ = "Someone me2@example.com"

# Old style still works
__contact__ = "Someone"
__contact_email__ = "me@example.com"
