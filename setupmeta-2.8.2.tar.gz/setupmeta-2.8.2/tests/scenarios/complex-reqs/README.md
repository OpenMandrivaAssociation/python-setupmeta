# Project with a complex requirements.txt file

This scenario tests parsing of a complex requirements.txt file (and all other info missing, including version)
