from setuptools import setup


setup(
    name="complex-reqs",
    setup_requires=["setupmeta"],
)
