# via_req_files spec

This scenario tests using references to requirement files from the the
`setup.py` spec.
