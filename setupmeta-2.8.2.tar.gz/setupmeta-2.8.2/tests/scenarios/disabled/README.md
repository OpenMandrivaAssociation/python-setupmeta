This project tests a setup.py where setupmeta is NOT activated
