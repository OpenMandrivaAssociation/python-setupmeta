from setuptools import setup


setup(
    name="pre-packaged",
    setup_requires=["setupmeta"],
    versioning="dev",
    url="http://example.com/pre-packaged",
)
